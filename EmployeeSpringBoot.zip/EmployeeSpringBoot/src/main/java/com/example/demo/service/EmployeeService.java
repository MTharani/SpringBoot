package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;

public interface EmployeeService {

	Employee saveEmployee(Employee employee);

	List<Employee> fetchEmployeeList();

	void deleteEmployeeById(Integer eid) throws EmployeeNotFoundException;

	Employee updateEmployee(Integer eid, Employee employee);

	Employee fetchByID(Integer eid) throws EmployeeNotFoundException;

	Employee fetchByName(String ename);

	Employee fetchBySalary(Double esalary);

	Employee fetchByEmailId(String email);

	Employee fetchByAge(Integer eage);

}
