package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.repositry.EmployeeRepo;

@Service

public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepo repo;

	@Override
	public Employee saveEmployee(Employee employee) {
		
		return repo.save(employee);
	}

	@Override
	public List<Employee> fetchEmployeeList() {
		
		return repo.findAll();
	}

	@Override
	public void deleteEmployeeById(Integer eid) throws EmployeeNotFoundException 
	{
		Optional<Employee> employee1=repo.findById(eid);
				if(!employee1.isPresent())
				{
					throw new EmployeeNotFoundException("Employee not Available");
				}
				else {
		repo.deleteById(eid);
				}
	}

	@Override
	public Employee updateEmployee(Integer eid, Employee employee) {
		
		return null;
	}

	@Override
	public Employee fetchByID(Integer eid) throws EmployeeNotFoundException {
		Optional<Employee> employee1=repo.findById(eid);
		if(!employee1.isPresent())
		{
			throw new EmployeeNotFoundException("Employee not Available");
		}
		
		
		return repo.getById(eid);
	}

	@Override
	public Employee fetchByName(String ename) {
		return repo.findByempName(ename);
	}

	@Override
	public Employee fetchBySalary(Double esalary) {
		// TODO Auto-generated method stub
		return repo.findByempSalary(esalary);
	}

	@Override
	public Employee fetchByEmailId(String email) {
		
		return repo.findByempEmailId(email);
	}

	@Override
	public Employee fetchByAge(Integer eage) {
		
		return repo.findByempAge(eage);
	}

}
