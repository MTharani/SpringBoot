package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;

public interface EmployeeService {

	Employee saveEmployee(Employee employee);

	List<Employee> fetchEmployeeList();

	void deleteEmployeeId(Integer eid) throws EmployeeNotFoundException;

	Employee updateemployee(Integer eid, Employee employee);

	Employee fetchEmployeeByName(String ename);

	Employee fetchEmployeetById(Integer eid) throws EmployeeNotFoundException;

	Employee fetchEmployeeBySala(Double esala);

	

	

}
