package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.error.EmployeeNotFoundException;
import com.example.demo.repository.EmployeeRepo;
@Service

public class EmployeeServiceImple implements EmployeeService {
	@Autowired
	EmployeeRepo repo;

	@Override
	public Employee saveEmployee(Employee employee) {

		return repo.save(employee);
	}

	@Override
	public List<Employee> fetchEmployeeList() {
		
		return repo.findAll();
	}

	@Override
	public void deleteEmployeeId(Integer eid) throws EmployeeNotFoundException {
		Optional<Employee> employee1= repo.findById(eid);//check in database
        if(!employee1.isPresent()) {
      	  throw new EmployeeNotFoundException("Employee not available");
        }
        else
        {
        	repo.deleteById(eid);
        }
		
	}

	@Override
	public Employee updateemployee(Integer eid, Employee employee) {
		Optional<Employee> employee1= repo.findById(eid);
		Employee epDB=null;
		if(employee1.isPresent()) {
			epDB=repo.findById(eid).get();
			if(Objects.nonNull(employee.getEname()) && !"".equalsIgnoreCase(employee.getEname())) {
				epDB.setEname(employee.getEname());

			}
			if(Objects.nonNull(employee.getEsala()) && !"".equals(employee.getEsala())) {
				epDB.setEsala(employee.getEsala());
				System.out.println(employee.getEsala());
			}
		}
		return repo.save(epDB);
	}

	@Override
	public Employee fetchEmployeeByName(String ename) {
		
		return repo.findByEname(ename);
		
	}

	@Override
	public Employee fetchEmployeetById(Integer eid) throws EmployeeNotFoundException{
		Optional<Employee> employee1= repo.findById(eid);//check in database
        if(!employee1.isPresent()) {
      	  throw new EmployeeNotFoundException("Employee not available");
        }
		return repo.findById(eid).get();
	}

	@Override
	public Employee fetchEmployeeBySala(Double esala) {
		// TODO Auto-generated method stub
		return repo.findByEsala(esala);
	}
	

	

}
