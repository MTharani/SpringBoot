package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int eid;
	private String ename;
	private double esala;
	public Employee() {
		super();
	}
	public Employee(int eid, String ename, double esala) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esala = esala;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getEsala() {
		return esala;
	}
	public void setEsala(double esala) {
		this.esala = esala;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esala=" + esala + "]";
	}


}
