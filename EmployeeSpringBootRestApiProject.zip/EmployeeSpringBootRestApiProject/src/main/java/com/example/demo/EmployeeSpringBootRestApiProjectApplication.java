package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSpringBootRestApiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSpringBootRestApiProjectApplication.class, args);
	}

}
