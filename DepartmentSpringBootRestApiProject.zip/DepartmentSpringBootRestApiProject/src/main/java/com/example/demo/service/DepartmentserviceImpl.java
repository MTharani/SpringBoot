package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.repository.DepartmentRepo;

@Service

public class DepartmentserviceImpl implements DepartmentService {

	@Autowired
	DepartmentRepo deprepo;
	@Override
	public Department saveDepartment(Department department) {
		// TODO Auto-generated method stub
		return  deprepo.save(department);
	}
	@Override
	public List<Department> fetchDepartmentList() {
		// TODO Auto-generated method stub
		return deprepo.findAll();
	}
	@Override
	public void deleteRecoredId(long departmentId) {
		deprepo.deleteById(departmentId);

	}

	@Override
	public Department updateDepartment(Long did, Department department) 
	{
		Optional<Department> department1= deprepo.findById(did);
		Department depDB=null;
		if(department1.isPresent()) {
			depDB=	deprepo.findById(did).get();
			if(Objects.nonNull(department.getDepartmentName()) && !"".equalsIgnoreCase(department.getDepartmentName())) {
				depDB.setDepartmentName(department.getDepartmentName());

			}
			if(Objects.nonNull(department.getDepartmentAddress()) && !"".equalsIgnoreCase(department.getDepartmentAddress())) {
				depDB.setDepartmentAddress(department.getDepartmentAddress());
				System.out.println(department.getDepartmentAddress());
			}
			if(Objects.nonNull(department.getDepartmentCode()) && !"".equals(department.getDepartmentCode())) {
				depDB.setDepartmentCode(department.getDepartmentCode());
				System.out.println(department.getDepartmentCode());
			}

		}
		return deprepo.save(depDB);

	}
	@Override
	public Department fetchDepartmentByName(String dname) {
		// TODO Auto-generated method stub
		return deprepo.findByDepartmentName(dname);
	}
	@Override
	public Department fetchDepartmentById(long did) throws DepartmentNotFoundException 
{
		// TODO Auto-generated method stub
		//check for null
				Optional<Department> department1= deprepo.findById(did);//check in database
		          if(!department1.isPresent()) {
		        	  throw new DepartmentNotFoundException("Department not available");
		          }
				return deprepo.findById(did).get();
			}

}
