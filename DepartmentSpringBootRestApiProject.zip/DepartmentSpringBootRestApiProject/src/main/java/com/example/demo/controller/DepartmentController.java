package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;
import com.example.demo.service.DepartmentService;

@RestController
public class DepartmentController
{

	@Autowired
	DepartmentService departmentService;
	@PostMapping("/departments/")
	public Department saveDepartment(@RequestBody Department department) {
		
		return departmentService.saveDepartment(department);
	}
	//getRecords
		@GetMapping("/departments/")
		public List<Department> fetchDepartmetList(){
			
			return departmentService.fetchDepartmentList();
		}
          @DeleteMapping("/departments/{id}")
          public String deleteRecordId(@PathVariable("id") long departmentId)
          {
        	  departmentService.deleteRecoredId(departmentId);
        	  return ("record deleted");
          
          }
          //update record
    	  @PutMapping("/departments/{id}")
    	  
    	  public Department updateDepartment(@PathVariable ("id") Long did, @RequestBody Department department) {
    		  
    		  return departmentService.updateDepartment(did,department);
    	  }
    	  @GetMapping("/departments/name/{name}")
    		public Department fetchDepartmentByName(@PathVariable("name") String dname) {
    			return departmentService.fetchDepartmentByName(dname);
    		}
    	  
    	  @GetMapping("/departments/{id}")
    	  public Department fetchDepartmentById(@PathVariable("id") long did) throws DepartmentNotFoundException
    	  {
    		  return departmentService.fetchDepartmentById(did);
    	  }


	

}
