package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Department;
import com.example.demo.error.DepartmentNotFoundException;

public interface DepartmentService {

	Department saveDepartment(Department department);

	List<Department> fetchDepartmentList();

	void deleteRecoredId(long departmentId);

	Department updateDepartment(Long did, Department department);

	Department fetchDepartmentByName(String dname);

	Department fetchDepartmentById(long did) throws DepartmentNotFoundException;

}
